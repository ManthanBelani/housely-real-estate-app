import 'package:flutter/material.dart';
import 'package:real_estate_app/constant/constant_color.dart';
import 'package:real_estate_app/screens/Auth/sign_up.dart';
import 'package:real_estate_app/widgets/reusable_text_field.dart';
import 'package:real_estate_app/widgets/reusable_button.dart';
import 'package:real_estate_app/widgets/social_media_button.dart';
import 'package:real_estate_app/widgets/auth_header_footer.dart';

import '../Forgot_Password/forgot_password.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isLoading = false;
  final _signInFormKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Form(
          key: _signInFormKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              const AuthHeader(
                title: 'Welcome Back !',
              ),
              const SizedBox(height: 20),
              EmailTextField(
                controller: _emailController,
              ),
              const SizedBox(height: 20),
              PasswordTextField(
                labelText: 'Password',
                controller: _passwordController,
              ),
              const SizedBox(height: 20),
              // Error message container (if needed)
              // if (errorMessage.isNotEmpty)
              //   Container(
              //     padding: EdgeInsets.all(10),
              //     decoration: BoxDecoration(
              //       color: Colors.red[50],
              //       borderRadius: BorderRadius.circular(5),
              //     ),
              //     child: Text(errorMessage, style: TextStyle(color: Colors.red)),
              //   ),
              // SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Checkbox(
                        activeColor: commonColor,
                        value: true,
                        onChanged: (value) {},
                      ),
                      const Text('Remember me', textAlign: TextAlign.left),
                    ],
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen(),));
                    },
                    child: Text(
                      'Forgot Password?',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: commonColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              ReusableButton(
                text: 'Sign In',
                onPressed: () {
                  if (_signInFormKey.currentState!.validate()) {
                    setState(() {
                      _isLoading = true;
                    });
                  }
                },
                isLoading: _isLoading,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 40, horizontal: 100),
                child: Center(child: Text('Or', style: TextStyle(fontSize: 15))),
              ),
              const SocialMediaButtonsRow(),
              const SizedBox(height: 20),
              AuthFooter(
                text: "Don't have account ?",
                linkText: 'Sign Up',
                linkColor: commonColor,
                onLinkTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_)=>SignUp()));
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
