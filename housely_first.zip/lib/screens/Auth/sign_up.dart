import 'package:flutter/material.dart';
import 'package:real_estate_app/constant/constant_color.dart';

import 'package:real_estate_app/widgets/reusable_text_field.dart';
import 'package:real_estate_app/widgets/reusable_button.dart';
import 'package:real_estate_app/widgets/social_media_button.dart';
import 'package:real_estate_app/widgets/auth_header_footer.dart';

import 'login_screen.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  bool _isLoading = false;
  final _signUpFormKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _termsAccepted = false;

  @override
  void dispose() {
    _emailController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Form(
          key: _signUpFormKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              const AuthHeader(title: 'Register Account'),
              const SizedBox(height: 20),
              EmailTextField(controller: _emailController),
              const SizedBox(height: 20),
              ReusableTextField(
                Tstyle: TextStyle(fontWeight: FontWeight.bold),
                labelText: 'UserName',
                hintText: 'Enter your username',
                controller: _usernameController,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your username';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              PasswordTextField(
                  labelText: 'Password',
                  controller: _passwordController),
              const SizedBox(height: 20),
              // Error message container (if needed)
              // if (errorMessage.isNotEmpty)
              //   Container(
              //     padding: EdgeInsets.all(10),
              //     decoration: BoxDecoration(
              //       color: Colors.red[50],
              //       borderRadius: BorderRadius.circular(5),
              //     ),
              //     child: Text(errorMessage, style: TextStyle(color: Colors.red)),
              //   ),
              // SizedBox(height: 20),
              Row(
                children: [
                  Checkbox(
                    activeColor: commonColor,
                    value: _termsAccepted,
                    onChanged: (value) {
                      setState(() {
                        _termsAccepted = value ?? false;
                      });
                    },
                  ),
                  Expanded(
                    child: Text(
                      'Agree with Terms and Privacy',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ReusableButton(
                text: 'Sign Up',
                onPressed: _termsAccepted
                    ? () {
                        if (_signUpFormKey.currentState!.validate()) {
                          // Handle sign up
                          setState(() {
                            _isLoading = true;
                          });
                          // Add your sign up logic here
                          // After sign up, set _isLoading back to false
                        }
                      }
                    : null, // Disable button if terms not accepted
                isLoading: _isLoading,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 40, horizontal: 100),
                child: Center(
                  child: Text('Or', style: TextStyle(fontSize: 15)),
                ),
              ),
              const SocialMediaButtonsRow(),
              const SizedBox(height: 20),
              AuthFooter(
                text: 'Already have account ?',
                linkText: 'Sign In',
                linkColor: commonColor,
                onLinkTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => LoginScreen()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
