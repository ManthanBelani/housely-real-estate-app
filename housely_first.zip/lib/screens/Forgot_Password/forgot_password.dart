import 'package:flutter/material.dart';
import 'package:real_estate_app/constant/constant_color.dart';


import '../../widgets/auth_header_footer.dart';
import '../../widgets/reusable_button.dart';
import 'email_verification_screen.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: AuthHeader(
                title: 'Forgot Password',
                subtitle:
                    'Select which contact details should we use to reset your password',
              ),
            ),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: ListTile(
                // style: ListTileStyle.drawer,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadiusGeometry.all(Radius.circular(10)),
                  side: BorderSide(color: commonColor),
                ),
                enabled: true,
                selectedColor: commonColor,
                contentPadding: EdgeInsets.all(20),
                focusColor: commonColor,
                title: Text('Via Email', style: TextStyle(fontSize: 15,color: Colors.blueGrey)),
                subtitle: Text(
                  'RainStreamWeb@gmail.com',
                  style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),
                ),
                leading: CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white,
                  child: Image.asset('assets/images/Message.png'),
                ),
              ),
            ),
            SizedBox(height: 350,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ReusableButton(
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => EmailVerificationScreen(),));
                },
                text: 'Continue',
                backgroundColor: commonColor,
                textColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
