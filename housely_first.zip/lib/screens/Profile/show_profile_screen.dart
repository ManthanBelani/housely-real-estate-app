import 'package:flutter/material.dart';
import 'package:real_estate_app/constant/constant_color.dart';
import 'package:real_estate_app/screens/Profile/edit_profile_screen.dart';

class ShowProfileScreen extends StatelessWidget {
  const ShowProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'Profile',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          children: [
            const ProfilePic(),
            SizedBox(height: 5),
            Text(
              'Rain Stream',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EditProfileScreen()),
                );
              },
              child: Text(
                'RainStreamweb@gmail.com',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
            ),
            SizedBox(height: 10),
            SizedBox(
              height: 50,
              width: 350,
              child: Divider(height: 2, color: Colors.grey, thickness: 1.1),
            ),
            const SizedBox(height: 20),
            ProfileMenu(
              text: "Settings",
              icon: "assets/images/Setting.png",
              press: () => {},
            ),
            ProfileMenu(
              text: "Payment",
              icon: "assets/images/Wallet.png",
              press: () {},
            ),
            ProfileMenu(
              text: "Notifications",
              icon: "assets/images/Notification.png",
              press: () {},
            ),
            ProfileMenu(
              text: "Recently Viewed",
              icon: "assets/images/TimeSquare.png",
              press: () {},
            ),
            ProfileMenu(
              text: "About",
              icon: "assets/images/InfoSquare.png",
              press: () {},
            ),
            Center(
              child: TextButton(
                onPressed: () {},
                child: Text(
                  'Sign Out',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Colors.red,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfilePic extends StatelessWidget {
  const ProfilePic({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      width: 100,
      child: Stack(
        fit: StackFit.expand,
        clipBehavior: Clip.none,
        children: [
          const CircleAvatar(
            backgroundImage: NetworkImage(
              'https://i.postimg.cc/0jqKB6mS/Profile-Image.png',
            ),
          ),
          Positioned(
            right: -0,
            bottom: 3,
            child: SizedBox(
              height: 35,
              width: 35,
              child: TextButton(
                style: TextButton.styleFrom(
                  disabledIconColor: commonColor,
                  // foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                    side: const BorderSide(color: Colors.deepPurpleAccent),
                  ),
                  // backgroundColor: const Color(0xFFF5F6F9),
                ),
                onPressed: () {},
                child: Image.asset(
                  'assets/images/Camera.png',
                  color: commonColor,
                  width: 40,
                  height: 40,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfileMenu extends StatelessWidget {
  const ProfileMenu({
    Key? key,
    required this.text,
    required this.icon,
    this.press,
  }) : super(key: key);

  final String text, icon;
  final VoidCallback? press;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      child: TextButton(
        style: TextButton.styleFrom(
          // foregroundColor: const Color(0xFFFF7643),
          padding: const EdgeInsets.all(15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          // backgroundColor: const Color(0xFFF5F6F9),
        ),
        onPressed: press,
        child: Row(
          children: [
            Image.asset(icon, width: 22),
            const SizedBox(width: 20),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
