import 'package:flutter/material.dart';
import 'package:real_estate_app/constant/constant_color.dart';

import 'Auth/login_screen.dart';
import 'Auth/sign_up.dart';
import 'Forgot_Password/email_verification_screen.dart';
import 'Forgot_Password/forgot_password.dart';
import 'Maps/map_intro_screen.dart';


class BottomTabNavScreen extends StatefulWidget {
  const BottomTabNavScreen({super.key});

  @override
  State<BottomTabNavScreen> createState() => _BottomTabNavScreenState();
}

class _BottomTabNavScreenState extends State<BottomTabNavScreen> {
  int _IndexSelected = 0;
  List<Widget> _page = [
    LoginScreen(),
    SignUp(),
    ForgotPasswordScreen(),
    MapIntroScreen(),
    EmailVerificationScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _page[_IndexSelected],
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: true,
        selectedItemColor: commonColor,
        // elevation: 2,
        // backgroundColor: Colors.black,
        // selectedLabelStyle: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
        currentIndex: _IndexSelected,
        onTap: (value) {
          setState(() {
            _IndexSelected = value;
          });
        },
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Column(
              children: [
                Container(
                  width: 40,
                  height: 3,
                  color: _IndexSelected == 0 ? commonColor : Colors.transparent,
                ),
                SizedBox(height: 15),
                Image.asset(

                  'assets/images/Home.png',
                  color: _IndexSelected == 0 ? commonColor : Colors.grey,
                  width: 24,
                  height: 24,
                ),
              ],
            ),
            // backgroundColor: Colors.black26,
            label: 'Home',
          ),
          BottomNavigationBarItem(
            // backgroundColor: commonColor,
            icon: Column(
              children: [
                Container(
                  width: 40,
                  height: 3,
                  color: _IndexSelected == 1 ? commonColor : Colors.transparent,
                ),
                SizedBox(height: 15),
                Image.asset(
                  'assets/images/Discovery.png',
                  color: _IndexSelected == 1 ? commonColor : Colors.grey,
                  width: 24,
                  height: 24,
                ),
              ],
            ),
            // backgroundColor: Colors.black26,
            label: 'Explore',
          ),
          BottomNavigationBarItem(
            icon: Column(
              children: [
                Container(
                  width: 40,
                  height: 3,
                  color: _IndexSelected == 2 ? commonColor : Colors.transparent,
                ),
                SizedBox(height: 15),
                Image.asset(
                  'assets/images/Heart.png',
                  color: _IndexSelected == 2 ? commonColor : Colors.grey,
                  width: 24,
                  height: 24,
                ),
              ],
            ),
            // backgroundColor: Colors.black26,
            label: 'Favourite',
          ),
          BottomNavigationBarItem(
            icon: Column(
              children: [
                Container(
                  width: 40,
                  height: 3,
                  color: _IndexSelected == 3 ? commonColor : Colors.transparent,
                ),
                SizedBox(height: 15),
                Image.asset(
                  'assets/images/Document.png',
                  color: _IndexSelected == 3 ? commonColor : Colors.grey,
                  width: 24,
                  height: 24,
                ),
              ],
            ),
            // backgroundColor: Colors.black26,
            label: 'Bookings',
          ),
          BottomNavigationBarItem(
            icon: Column(
              children: [
                Container(
                  width: 40,
                  height: 3,
                  color: _IndexSelected == 4 ? commonColor : Colors.transparent,
                ),
                SizedBox(height: 15),
                Image.asset(
                  'assets/images/Profile.png',
                  color: _IndexSelected == 4 ? commonColor : Colors.grey,
                  width: 24,
                  height: 24,
                ),
              ],
            ),
            // backgroundColor: Colors.black26,
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
