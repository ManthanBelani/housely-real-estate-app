import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Future<User?> signInWithGoogle() async {
  //   try {
  //     final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
  //
  //     if (googleUser == null) return null;
  //
  //     final GoogleSignInAuthentication googleAuth =
  //         await googleUser.authentication;
  //
  //     final credential = GoogleAuthProvider.credential(
  //       accessToken: googleAuth.accessToken,
  //       idToken: googleAuth.idToken,
  //     );
  //
  //     UserCredential userCredential = await _auth.signInWithCredential(
  //       credential,
  //     );
  //
  //     User? user = userCredential.user;
  //
  //     if (user == null) return null;
  //
  //     DocumentReference userDocRef = _firestore
  //         .collection('users')
  //         .doc(user.uid);
  //
  //     DocumentSnapshot userDoc = await userDocRef.get();
  //
  //     if (!userDoc.exists) {
  //       // Create a new user document in Firestore
  //       await userDocRef.set({
  //         'name': user.displayName,
  //         'email': user.email,
  //         'phoneNumber': user.phoneNumber,
  //         'photoURL': user.photoURL,
  //         'createdAt': FieldValue.serverTimestamp(),
  //         'updatedAt': FieldValue.serverTimestamp(),
  //       });
  //       print('New user document created for ${user.displayName}');
  //     } else {
  //       await userDocRef.update({'updatedAt': FieldValue.serverTimestamp()});
  //       print('Returning user: ${user.displayName}');
  //     }
  //
  //     return user;
  //   } catch (e) {
  //     print('Google Sign-In Error: $e');
  //     rethrow;
  //   }
  // }

  Future<User?> signUpWithEmail(
    String email,
    String password,
    String name,
  ) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      User? user = userCredential.user;
      if (user == null) return null;
      await user.updateDisplayName(name);
      await createOrUpdateUserDoc(user, nameOverrides: name);
      await user.reload();
      user = _auth.currentUser;
      return user;
    } catch (e) {
      print('Email Sign-Up Error: $e');
      rethrow;
    }
  }

  Future<User?> signInWithEmail(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      User? user = userCredential.user;
      if (user == null) return null;
      await user.reload();
      user = _auth.currentUser;
      await createOrUpdateUserDoc(user);
      print('Returning user: ${user?.displayName ?? user?.email}');
    } catch (e) {
      print('Email Sign-In Error: $e');
      rethrow;
    }
    return null;
  }

  Future<User?> createOrUpdateUserDoc(user, {String? nameOverrides}) async {
    try {
      DocumentReference userDocRef = _firestore
          .collection('users')
          .doc(user.uid);
      DocumentSnapshot userDoc = await userDocRef.get();

      if (!userDoc.exists) {
        await userDocRef.set({
          'name': user.displayName ?? nameOverrides,
          'email': user.email,
          'phoneNumber': user.phoneNumber,
          'photoURL': user.photoURL,
        });

        print(
          'New user document created for ${user.displayName ?? user.email}',
        );
      }
    } catch (e) {
      print('User Document Error: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    try {
      // await GoogleSignIn().signOut();
      await _auth.signOut();
      print('User signed out');
    } catch (e) {
      print('Sign-Out Error: $e');
      rethrow;
    }
  }
}
